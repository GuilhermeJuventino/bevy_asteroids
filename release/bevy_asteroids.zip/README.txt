Bevy Asteroids Readme

You will need the keyboard to play this game!
Controls: Use the arrow keys to move, left and right to turn the ship, up to move in the direction you're facing. Press Z to shoot.